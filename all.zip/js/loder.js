$(document).ready(function(){
    $('.modal').modal();
    $('.parallax').parallax();
    $('.sidenav').sidenav();
    $('.slider').slider();
    $('.carousel').carousel({
        numVisible:7,
        shift: 70,
        padding:80,
    });
})

function togglemodal(){
    var instance=M.Modal.getInstance($('#modal3'))
    instance.open();
}

